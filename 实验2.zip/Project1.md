## 1.Install Jupyterlab

### 1.在PowerShell或CMD中使用命令: pip install jupyterlab(若没有python环境需安装python3)

![image-20220414151910639](Project1.assets/image-20220414151910639-16499263519111-16499263565012.png)

### 2.若提示升级，建议升级一下(需使用管理员权限)

![image-20220414152109604](Project1.assets/image-20220414152109604.png)

### 3.访问jupyter-lab

![image-20220414152149468](Project1.assets/image-20220414152149468-16499266296803.png)



![image-20220414153613263](Project1.assets/image-20220414153613263.png)

