# Project2

## 首先，建立一个新的Kotlin项目

## 按照要求添加代码

![Screenshot_2022-05-05-09-50-18-677_com.example.random](\project2.assets\Screenshot_2022-05-05-09-50-18-677_com.example.random-16517154442421.jpg)

![Screenshot_2022-05-05-09-51-08-023_com.example.random](project2.assets\Screenshot_2022-05-05-09-51-08-023_com.example.random-16517154922492.jpg)